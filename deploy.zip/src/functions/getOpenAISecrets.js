"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getOpenAISecrets = getOpenAISecrets;
const functions_1 = require("@azure/functions");
const keyvault_secrets_1 = require("@azure/keyvault-secrets");
const identity_1 = require("@azure/identity");
// CORS headers for React app
const corsHeaders = {
    'Access-Control-Allow-Origin': '*', // Will be configured based on environment
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Content-Type': 'application/json'
};
// Check if origin is allowed
function isOriginAllowed(origin) {
    var _a;
    const allowedOrigins = ((_a = process.env.ALLOWED_ORIGINS) === null || _a === void 0 ? void 0 : _a.split(',')) || ['http://localhost:3000'];
    return allowedOrigins.includes(origin);
}
// Get secrets from Azure Key Vault
async function getSecretsFromKeyVault() {
    try {
        const keyVaultUrl = process.env.KEY_VAULT_URL;
        if (!keyVaultUrl) {
            throw new Error('KEY_VAULT_URL environment variable is not set');
        }
        const credential = new identity_1.DefaultAzureCredential();
        const client = new keyvault_secrets_1.SecretClient(keyVaultUrl, credential);
        const apiKeySecretName = process.env.AZURE_OPENAI_API_KEY_SECRET_NAME || 'azure-openai-api-key';
        const endpoint = process.env.AZURE_OPENAI_ENDPOINT;
        if (!endpoint) {
            throw new Error('AZURE_OPENAI_ENDPOINT environment variable is not set');
        }
        // Retrieve the API key from Key Vault
        const secret = await client.getSecret(apiKeySecretName);
        if (!secret.value) {
            throw new Error('Failed to retrieve API key from Key Vault');
        }
        return {
            endpoint: endpoint,
            apiKey: secret.value
        };
    }
    catch (error) {
        throw new Error(`Failed to retrieve secrets: ${error.message}`);
    }
}
// Fallback to environment variables (for development)
function getSecretsFromEnvironment() {
    const endpoint = process.env.AZURE_OPENAI_ENDPOINT;
    const apiKey = process.env.AZURE_OPENAI_API_KEY;
    if (!endpoint || !apiKey) {
        throw new Error('Required environment variables AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_API_KEY are not set');
    }
    return { endpoint, apiKey };
}
async function getOpenAISecrets(request, context) {
    context.log('Azure OpenAI secrets request received');
    // Handle CORS preflight
    if (request.method === 'OPTIONS') {
        return {
            status: 200,
            headers: corsHeaders
        };
    }
    // Only allow GET requests
    if (request.method !== 'GET') {
        return {
            status: 405,
            headers: corsHeaders,
            body: JSON.stringify({
                success: false,
                error: 'Method not allowed'
            })
        };
    }
    try {
        // Check origin for CORS
        const origin = request.headers.get('origin') || '';
        if (origin && !isOriginAllowed(origin)) {
            return {
                status: 403,
                headers: corsHeaders,
                body: JSON.stringify({
                    success: false,
                    error: 'Origin not allowed'
                })
            };
        }
        // Set the allowed origin in response headers
        const responseHeaders = {
            ...corsHeaders,
            'Access-Control-Allow-Origin': origin || corsHeaders['Access-Control-Allow-Origin']
        };
        let config;
        // Try to get secrets from Key Vault first, fallback to environment variables
        try {
            config = await getSecretsFromKeyVault();
            context.log('Successfully retrieved secrets from Key Vault');
        }
        catch (keyVaultError) {
            context.log('Key Vault retrieval failed, falling back to environment variables:', keyVaultError.message);
            config = getSecretsFromEnvironment();
            context.log('Successfully retrieved secrets from environment variables');
        }
        return {
            status: 200,
            headers: responseHeaders,
            body: JSON.stringify({
                success: true,
                data: config
            })
        };
    }
    catch (error) {
        context.log('Error retrieving OpenAI configuration:', error);
        return {
            status: 500,
            headers: corsHeaders,
            body: JSON.stringify({
                success: false,
                error: 'Failed to retrieve OpenAI configuration'
            })
        };
    }
}
functions_1.app.http('getOpenAISecrets', {
    methods: ['GET', 'OPTIONS'],
    authLevel: 'anonymous',
    route: 'openai/config',
    handler: getOpenAISecrets
});
//# sourceMappingURL=getOpenAISecrets.js.map