"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.KeyVaultService = void 0;
const keyvault_secrets_1 = require("@azure/keyvault-secrets");
const identity_1 = require("@azure/identity");
class KeyVaultService {
    constructor(keyVaultUrl) {
        const credential = new identity_1.DefaultAzureCredential();
        this.client = new keyvault_secrets_1.SecretClient(keyVaultUrl, credential);
    }
    async getSecret(secretName) {
        try {
            const secret = await this.client.getSecret(secretName);
            if (!secret.value) {
                throw new Error(`Secret ${secretName} has no value`);
            }
            return secret.value;
        }
        catch (error) {
            throw new Error(`Failed to retrieve secret ${secretName}: ${error.message}`);
        }
    }
}
exports.KeyVaultService = KeyVaultService;
//# sourceMappingURL=keyVaultService.js.map